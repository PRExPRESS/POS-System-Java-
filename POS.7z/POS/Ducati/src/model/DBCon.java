/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Pasindu
 */
public class DBCon {
    static Connection con;
    static Statement stmt;
    public static Connection getcon(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/ducati";
            con = DriverManager.getConnection(url, "root", "");
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return con;
    }
    public static void closeCon() throws SQLException{
        con.close();
    }
}
