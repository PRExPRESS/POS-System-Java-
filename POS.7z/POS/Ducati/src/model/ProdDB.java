/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pasindu
 */
public class ProdDB {
    public static ResultSet prodRs;
    public static ResultSet rs;
    public void addProd(String chNo,  String model, String engine, String price, String year){
        Statement stmt =null;
        try {
            Connection con =DBCon.getcon();
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO product VALUES('"+chNo+"','"+model+"','"+engine+"','"+price+"','"+year+"','Active')");
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }
    public static ResultSet prodSearch(){
        try{
            Connection con = DBCon.getcon();
            Statement st = con.createStatement();
            String sql ="SELECT * FROM product";
            prodRs = st.executeQuery(sql);
            
        }catch(Exception e){
            System.out.println(e);
        }
        System.out.println(prodRs+"db ok");
         return prodRs;
    }
       
    public  ResultSet productSrch(String chNo){
        
        try {
            
            Connection con = DBCon.getcon();
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT *FROM product WHERE ch_num LIKE '%"+chNo+"%'");
        } catch (SQLException ex) {
            Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
      //  System.out.println(rsa);
        return rs;
    }
    public void updateProd(String chNo, String model, String engine, String price, String year){
        Statement stmt =null;
       //System.out.println(_contact+" in db pass");
//        System.out.println(empId+" in db pass");
            try {
                Connection con =DBCon.getcon();
                stmt = con.createStatement();
                stmt.executeUpdate("UPDATE product SET ch_num='"+chNo+"',model='"+model+"',engine='"+engine+"',price='"+price+"',year='"+year+"' WHERE ch_num='"+chNo+"'");
                                                                                       
            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
    
    
    public void deleteProd(String chNo){
        Statement stmt =null;
      
            try {
                Connection con =DBCon.getcon();
                stmt = con.createStatement();
                stmt.executeUpdate("DELETE FROM product WHERE ch_num='"+chNo+"'");
                                                                                       
            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
            } 
        
        }
        
}
