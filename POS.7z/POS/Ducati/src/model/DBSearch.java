/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pasindu
 */
public class DBSearch {
    Statement stmt;
    ResultSet rs;
    public ResultSet users;
    public ResultSet rsUser;
    
    public ResultSet searchLogin(String usname){
        System.out.println(usname);
        try{
            Connection con = DBCon.getcon();
            stmt = con.createStatement();
            String usename =usname;
            rs = stmt.executeQuery("SELECT * FROM user WHERE username= '"+usename+"'");
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet userSearch(){
        try{
            Connection con = DBCon.getcon();
            Statement st = con.createStatement();
            String sql ="SELECT * FROM user";
             users = st.executeQuery(sql);
            
        }catch(Exception e){
            System.out.println(e);
        }
        
        return users;
    }
    public ResultSet searchUser(String empId){
        String empid =empId;
        //String name=null;
        System.out.println(empid+" seach db pass");
        try{
            Connection con = DBCon.getcon();
            stmt = con.createStatement();
            rsUser = stmt.executeQuery("SELECT * FROM user WHERE emp_id= '"+empid+"'");
              
        }catch(Exception e){
            e.printStackTrace();
        }
        return rsUser;
    }
    
}

