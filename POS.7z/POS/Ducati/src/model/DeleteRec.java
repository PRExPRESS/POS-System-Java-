/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pasindu
 */
public class DeleteRec {
    
    public void deleteUser(String empId){
        Statement stmt =null;
      
            try {
                Connection con =DBCon.getcon();
                stmt = con.createStatement();
                stmt.executeUpdate("DELETE FROM user WHERE emp_id='"+empId+"'");
                                                                                       
            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
            } 
        
        }
    }
    

