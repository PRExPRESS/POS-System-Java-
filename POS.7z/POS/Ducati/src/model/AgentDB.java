/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pasindu
 */
public class AgentDB {
    Statement stmt;
    public ResultSet rs;
    public void addAgent(String agID, String name, String contact, String email, String address){
        Statement stmt =null;
        try {
            Connection con =DBCon.getcon();
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO agent VALUES('"+agID+"','"+name+"','"+contact+"','"+email+"','"+address+"')");
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }
    
    public ResultSet searchAgent(){
        //System.out.println(usname);
        try{
            Connection con = DBCon.getcon();
            stmt = con.createStatement();
            
            rs = stmt.executeQuery("SELECT * FROM agent");
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return rs;
    }
    
    public  ResultSet agentSrch(String agId){
        rs=null;
        try {
            
            Connection con = DBCon.getcon();
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT *FROM agent WHERE agent_id LIKE '%"+agId+"%'");
        } catch (SQLException ex) {
            Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
      //  System.out.println(rsa);
        return rs;
    }
    public  ResultSet agSrch(String agId){
        rs=null;
        try {
            
            Connection con = DBCon.getcon();
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT *FROM agent WHERE agent_id LIKE '%"+agId+"%'");
        } catch (SQLException ex) {
            Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
      //  System.out.println(rsa);
        return rs;
    }
    
    public void updateAg(String agId, String name, String contact, String email, String address){
        Statement stmt =null;
      
            try {
                Connection con =DBCon.getcon();
                stmt = con.createStatement();
                stmt.executeUpdate("UPDATE agent SET agent_id='"+agId+"',name='"+name+"',contact='"+contact+"',email='"+email+"',address='"+address+"' WHERE agent_id='"+agId+"'");
                                                                                       
            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
    
    public void deleteAgent(String agId){
        Statement stmt =null;
      
            try {
                Connection con =DBCon.getcon();
                stmt = con.createStatement();
                stmt.executeUpdate("DELETE FROM agent WHERE agent_id='"+agId+"'");
                                                                                       
            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
            } 
        
        }
}


