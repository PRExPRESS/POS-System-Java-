/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pasindu
 */
public class AddRecord {
    public void adduser(String empid, String name, String uName, String pin, String email, String contact){
        Statement stmt =null;
        try {
            Connection con =DBCon.getcon();
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO user VALUES('"+empid+"','"+name+"','"+uName+"','"+pin+"','"+email+"','"+contact+"')");
        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }
    // Update Query
    public void updateuser(String empId, String _name, String uName, String _pin, String _email, String _contact){
        Statement stmt =null;
       System.out.println(_contact+" in db pass");
//        System.out.println(empId+" in db pass");
            try {
                Connection con =DBCon.getcon();
                stmt = con.createStatement();
                stmt.executeUpdate("UPDATE user SET emp_id='"+empId+"',name='"+_name+"',username='"+uName+"',pin='"+_pin+"',email='"+_email+"',contact='"+_contact+"' WHERE emp_id='"+empId+"'");
                                                                                       
            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(AddRecord.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
    }
    
    

