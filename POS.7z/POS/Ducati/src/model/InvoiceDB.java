/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pasindu
 */
public class InvoiceDB {
    public InvoiceDB(){}
    public ResultSet rs;
    public static int lIId;
   
    public ResultSet agentSrch( String name){
      //  System.out.println(name+" name pass!");
        try {
            
            Connection con = DBCon.getcon();
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT *FROM agent WHERE name LIKE '"+name+"%'");
        } catch (SQLException ex) {
            Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
      //  System.out.println(rsa);
        return rs;
    }
    
    public ResultSet productSrch( String pId){
        rs =null;
        try {
            
            Connection con = DBCon.getcon();
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT *FROM product WHERE ch_num LIKE '"+pId+"%'");
        } catch (SQLException ex) {
            Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
      //  System.out.println(rsa);
        return rs;
    }
    //add invoice to Database
    public int addinvoiceSales(String chNo, float total){
        PreparedStatement pst;
        
        
        
        SimpleDateFormat dFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dte=new Date();
        String date=dFormat.format(dte);
        
        try {
            Connection con =DBCon.getcon();
            
            //find agent id
            
           // System.out.println(aId+" "+chNo+" "+date);
            rs=null;
            
            // insert invoice data
           String sql = "INSERT INTO sales(date,total) VALUES (?,?)";
           pst =con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
           pst.setString(1,date);
           pst.setFloat(2, total);
           pst.executeUpdate();
           ResultSet gKey =pst.getGeneratedKeys();
           
           if(gKey.next()){
               lIId=gKey.getInt(1);
           }
           
           
                                                                                                        
            //delete row of product table
            
            
        } catch (SQLException ex) {
            Logger.getLogger(InvoiceDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lIId;
        
    }
    public void addInvoiceSP(int lastInsrtId, String aName, String chNo, float price){
        PreparedStatement pst1;
        Statement stmt=null;
        String aId="";
        try {
            Connection con =DBCon.getcon();
            stmt = con.createStatement();
            //find agent id
            rs= stmt.executeQuery("SELECT * FROM agent WHERE name = '"+aName+"'");
            while(rs.next()){
                aId =rs.getString("agent_id");
            }
            rs= stmt.executeQuery("SELECT * FROM sales WHERE sales_id = '"+aName+"'");
            while(rs.next()){
                aId =rs.getString("agent_id");
            }
            String ssql = "INSERT INTO sales_product(sales_id,agent_id,ch_num,price) VALUES (?,?,?,?)";
            pst1=con.prepareStatement(ssql);
            pst1.setInt(1, lastInsrtId);
            pst1.setString(2, aId);
            pst1.setString(3, chNo);
            pst1.setFloat(4, price);
            pst1.executeUpdate();
           //stmt.executeUpdate("UPDATE product SET status= 'Sold' WHERE ch_num = '"+chNo+"'");
           
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    
//    public void addInvoice(int rc,String aName, String chNo,float total,float price){
//        String aId="";
//        try {
//            Connection con =DBCon.getcon();
//            Statement stmt;
//            stmt = con.createStatement();
//            //find agent id
//            rs= stmt.executeQuery("SELECT * FROM agent WHERE name = '"+aName+"'");
//            while(rs.next()){
//                aId =rs.getString("agent_id");
//            }
//            
//            addinvoiceSales(aName,chNo,total);
//            for(int i=0;i<rc;i++){
//                addInvoiceSP(aId,chNo,price);
//            }
//            
//            
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
        
     
}
