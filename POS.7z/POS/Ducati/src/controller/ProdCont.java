/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.AddRecord;
import model.DBCon;
import model.DBSearch;
import model.DeleteRec;
import model.ProdDB;
import view.EditProd;
import view.EditUser;

/**
 *
 * @author Pasindu
 */
public class ProdCont {
    public  String cha_No;
    public  String model;
    public  String engine;
    public  String price;
    public  String year;
    
    
    
    public static void addProd(String chNo,  String model, String engine, String price, String year){
        ProdDB ar = new ProdDB();
        ar.addProd( chNo,   model, engine,  price,  year);
        JOptionPane.showMessageDialog(null,"Added!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
        try {
            DBCon.closeCon();
        } catch (SQLException ex) {
            Logger.getLogger(UserCont.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void UpdateProdCont(String chNo, String model, String engine, String price, String year){
        String ch_No=null;
        String _model=null;
        String _engine=null;
        String _price = null;
        String _year =null;
        
        
        ch_No =chNo;
        _model =model;
        _engine =engine;
        _price = price;
        _year =year;
        
        if(ch_No.equals("Enter Chassi No")){
            ch_No=null;
        }
        if(_model.equals("Enter Model")){
            _model=null;
        }
        if(_engine.equals("Enter Engine")){
            _engine=null;
        }
        if(_price.equals("Enter Price")){
            _price=null;
        }
        if(_year.equals("Enter Year")){
            _year =null;
        }
        
//        System.out.println(empid+" EMP ID is ok");
//        System.out.println(contact);
        
         if(ch_No !=null && _model !=null && _engine !=null && _price !=null && _year !=null ){
            ProdDB ar = new ProdDB();
            ar.updateProd(ch_No, _model, _engine, _price, _year );
            JOptionPane.showMessageDialog(null,"Update Successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
            try {
                DBCon.closeCon();
            } catch (SQLException ex) {
                Logger.getLogger(UserCont.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
             JOptionPane.showMessageDialog(null, "Field must be filled!", "Error",JOptionPane.INFORMATION_MESSAGE);
         }
    }
    public void srchCon(String chNo){
    
        
        try{
            String ch_No = chNo;
           // System.out.println(empID);
            ResultSet rs =new ProdDB().productSrch(ch_No);
             while(rs.next()){
                 cha_No=rs.getString(1);
                 model=rs.getString(2);
                 engine=rs.getString(3);
                 price=rs.getString(4);
                 year=rs.getString(5);
             }     
//             System.out.println(name+ " Search Cont OK");
//             System.out.println(uname+ " Search Cont OK");
//             System.out.println(pin+ " Search Cont OK");
//             System.out.println(email+ " Search Cont OK");
//             System.out.println(contact+ " Search Cont OK");
        DBCon.closeCon();   
        }catch(Exception e){
            e.printStackTrace();
        }
       
    }
    
    public static void delProd(String chNo){
        if(chNo.equals("Enter Chassi  No")){
            chNo=null;
        }
        if(chNo !=null){
            int a= JOptionPane.showConfirmDialog(null,"Do you want delete this record?","Confirm", JOptionPane.YES_NO_OPTION);
            if(a==0){
                ProdDB dR = new ProdDB();
                dR.deleteProd(chNo);
                JOptionPane.showMessageDialog(null,"Delete Successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
                EditUser.getFrames()[0].dispose();
                new EditProd().setVisible(true);
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "Please enter the EMP ID!", "Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }

}
