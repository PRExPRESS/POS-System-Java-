/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.AddRecord;
import model.AgentDB;
import model.DBCon;
import view.EditAgent;

/**
 *
 * @author Pasindu
 */
public class AgentCont {
    public  String agID;
    public  String name;
    public  String contact;
    public  String email;
    public  String address;
    public static void addAgent(String agId, String name, String contact, String email, String address){
        AgentDB ar = new AgentDB();
        ar.addAgent(agId, name, contact, email, address);
        JOptionPane.showMessageDialog(null,"Added!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
        try {
            DBCon.closeCon();
        } catch (SQLException ex) {
            Logger.getLogger(UserCont.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void srchCon(String agId){
   
        try{
            
           // System.out.println(empID);
            ResultSet rs =new AgentDB().agSrch(agId);
             while(rs.next()){
                 agID=rs.getString(1);
                 name=rs.getString(2);
                 contact=rs.getString(3);
                 email=rs.getString(4);
                 address=rs.getString(5);
             }     
//             System.out.println(name+ " Search Cont OK");
//             System.out.println(uname+ " Search Cont OK");
//             System.out.println(pin+ " Search Cont OK");
//             System.out.println(email+ " Search Cont OK");
//             System.out.println(contact+ " Search Cont OK");
        DBCon.closeCon();   
        }catch(Exception e){
            e.printStackTrace();
        }
       
    }
    
    public static void UpdateAgCont(String agId, String name, String contact, String email, String address){
        
        String agID=null;
        String aName=null;
        String acontact=null;
        String aEmail = null;
        String aAddress =null;
        
        
        agID =agId;
        aName =name;
        acontact =contact;
        aEmail = email;
        aAddress =address;
        
        if(agID.equals("")){
            agID=null;
        }
        if(aName.equals("")){
            name=null;
        }
        if(aName.equals("")){
            aName=null;
        }
        if(aEmail.equals("")){
            aEmail=null;
        }
        if(aAddress.equals("")){
            aAddress =null;
        }
        
        
        if(agID !=null && aName !=null && acontact !=null && aEmail !=null && aAddress !=null ){   
            
            AgentDB ab = new AgentDB();
            ab.updateAg( agId, name, contact, email, address);
            JOptionPane.showMessageDialog(null,"Update Successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
            try {
                DBCon.closeCon();
            } catch (SQLException ex) {
                Logger.getLogger(UserCont.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
             JOptionPane.showMessageDialog(null, "Field must be filled!", "Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }
    public static void delAgent(String agId){
        if(agId.equals("Enter Agent Id")){
            agId=null;
        }
        if(agId !=null){
            int a= JOptionPane.showConfirmDialog(null,"Do you want delete this record?","Confirm", JOptionPane.YES_NO_OPTION);
            if(a==0){
                AgentDB dA = new AgentDB();
                dA.deleteAgent(agId);
                JOptionPane.showMessageDialog(null,"Delete Successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
                EditAgent.getFrames()[0].dispose();
                new EditAgent().setVisible(true);
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "Please enter the EMP ID!", "Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
