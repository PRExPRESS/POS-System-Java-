/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.AddRecord;
import model.DBCon;
import model.DeleteRec;
import view.AddUser;
import view.EditUser;

/**
 *
 * @author Pasindu
 */
public class UserCont {
    public static void addUser(String empid, String name, String uName, String pin, String email, String contact){
        AddRecord ar = new AddRecord();
        ar.adduser(empid, name, uName, pin, email, contact);
        JOptionPane.showMessageDialog(null,"Added!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
        try {
            DBCon.closeCon();
        } catch (SQLException ex) {
            Logger.getLogger(UserCont.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /// Update User Details
    
    public static void UserUpdateCont(String empId, String _name, String uName, String _pin, String _email, String _contact){
        String empid=null;
        String name=null;
        String uname=null;
        String pin = null;
        String email =null;
        String contact =null;
        
        empid =empId;
        name =_name;
        uname =uName;
        pin = _pin;
        email =_email;
        contact =_contact;
        if(empid.equals("Enter EMP ID")){
            empid=null;
        }
        if(name.equals("Enter Name")){
            name=null;
        }
        if(uname.equals("Enter Username")){
            uname=null;
        }
        if(pin.equals("Enter PIN")){
            pin=null;
        }
        if(email.equals("Enter Email")){
            email =null;
        }
        if(contact.equals("Enter Contact")){
            contact=null;
        }
//        System.out.println(empid+" EMP ID is ok");
//        System.out.println(contact);
        
         if(empid !=null && name !=null && uname !=null && pin !=null && email !=null && contact !=null){
            AddRecord ar = new AddRecord();
            ar.updateuser(empid, name, uName, pin, email, contact);
            JOptionPane.showMessageDialog(null,"Update Successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
            try {
                DBCon.closeCon();
            } catch (SQLException ex) {
                Logger.getLogger(UserCont.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
             JOptionPane.showMessageDialog(null, "Field must be filled!", "Error",JOptionPane.INFORMATION_MESSAGE);
         }
    }
    public static void delUser(String empId){
        if(empId.equals("Enter EMP ID")){
            empId=null;
        }
        if(empId !=null){
            int a= JOptionPane.showConfirmDialog(null,"Do you want delete this record?","Confirm", JOptionPane.YES_NO_OPTION);
            if(a==0){
                DeleteRec dR = new DeleteRec();
                dR.deleteUser(empId);
                JOptionPane.showMessageDialog(null,"Delete Successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
                EditUser.getFrames()[0].dispose();
                new EditUser().setVisible(true);
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "Please enter the EMP ID!", "Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }
}





    


















