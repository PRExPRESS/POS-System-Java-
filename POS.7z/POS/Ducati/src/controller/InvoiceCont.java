/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import static com.sun.glass.ui.Cursor.setVisible;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.JOptionPane;
import model.DBCon;
import model.InvoiceDB;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import view.Bill;

/**
 *
 * @author Pasindu
 */
public class InvoiceCont {
   // public String AID;
    public static String aName=null;
    public static String aCont=null;
    public static String aEmail=null;
    public static String aAddress=null;
   //
    public static String pid=null;
    public static String model=null;
    public static String price=null;
    public static String mYear=null;
    public static String stat=null;
    static int lastInsrtId=0;
    
    
    public static void srchAgent(String name){
        
        try {
            ResultSet rs =new InvoiceDB().agentSrch(name);
           // System.out.println(name+" name pass!");
            if(rs.next()){
               aName=rs.getString(2);
               aCont=rs.getString(3);
               aEmail=rs.getString(4);
               aAddress=rs.getString(5);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
   public static void srchProd(String pId){
        
        try{
            
            ResultSet rs =new InvoiceDB().productSrch(pId);
           // System.out.println(name+" name pass!");
            if(rs.next()){
               stat = rs.getString(6);
               pid=rs.getString(1);
               model=rs.getString(2);
               price=rs.getString(4);
               mYear=rs.getString(5);
             }
              
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   public static void addBillCon1(String chNo,float total){
      // ResultSet rs=null;
       try {
          
           InvoiceDB ic=new InvoiceDB();
          ic.addinvoiceSales(chNo,total);

           DBCon.closeCon();  
  
       } catch (Exception e) {
       }
       System.out.println(lastInsrtId);
        ;
       
   }
   public static void addBillCon2(String aNme,String chNo,float price){
       try {
            lastInsrtId=InvoiceDB.lIId;
            System.out.println(lastInsrtId);
            InvoiceDB ic=new InvoiceDB();
            ic.addInvoiceSP(lastInsrtId,aNme, chNo, price);
           DBCon.closeCon();
       } catch (Exception e) {
       }       
   }
   public static void printInvo(){
       lastInsrtId=InvoiceDB.lIId;
       String invoNo=String.valueOf(lastInsrtId);
       HashMap m=new HashMap();
       m.put("invoiceNo",invoNo);
       try {
           Connection con =DBCon.getcon();
           JasperDesign jDesign = JRXmlLoader.load(new FileInputStream(new File(".\\src\\view\\Invoice.jrxml")));
           JasperReport ireport = JasperCompileManager.compileReport(jDesign);
           JasperPrint jPrint = JasperFillManager.fillReport(ireport,m,con);
           
           //JasperViewer.viewReport(jPrint);
          JasperPrintManager.printReport(jPrint, false);
           //stem.out.println("Done exporting reports to pdf");
           Bill.getFrames()[1].dispose();
           new Bill().setVisible(true);
           
           DBCon.closeCon();
           
       } catch (Exception e) {
           System.out.println(e);
       }
   }
    public static void main(String[] args) {
        printInvo();
    }
}
