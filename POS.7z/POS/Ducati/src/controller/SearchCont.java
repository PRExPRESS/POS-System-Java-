/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.ResultSet;
import model.DBSearch;
import view.EditUser;

/**
 *
 * @author Pasindu
 */
public class SearchCont {
    public String name=null;
    public String uname=null;
    public String pin=null;
    public String email=null;
    public String contact=null;
    
    public  ResultSet rs;
    
    public  ResultSet srchCon(String empId){
    
        //String empID = empId;
        try{
            String empID = empId;
            System.out.println(empID);
            ResultSet rs =new DBSearch().searchUser(empID);
             while(rs.next()){
                 name=rs.getString(2);
                 uname=rs.getString(3);
                 pin=rs.getString(4);
                 email=rs.getString(5);
                 contact=rs.getString(6);
             }     
//             System.out.println(name+ " Search Cont OK");
//             System.out.println(uname+ " Search Cont OK");
//             System.out.println(pin+ " Search Cont OK");
//             System.out.println(email+ " Search Cont OK");
//             System.out.println(contact+ " Search Cont OK");
             
        }catch(Exception e){
            
        }
        return rs;
    }
        
    
}
