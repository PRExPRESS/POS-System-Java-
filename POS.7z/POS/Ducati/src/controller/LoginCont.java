/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.DBCon;
import model.DBSearch;
import view.Home;
import view.Login;
import view.LoginBack;


/**
 *
 * @author Pasindu
 */
public class LoginCont {
    
    public ResultSet rs;
    public static String userName =null;
    LoginCont(){}
    public static void loginCon(String uname, String passwd){
        
        try{
            String usname =uname;
            String paswd = passwd;
            String username =null;
            String password =null;
            
            ResultSet rs =new DBSearch().searchLogin(usname);
            while (rs.next()){
                username =rs.getString("username");
                password = rs.getString("pin");
            }
            //Validation
            userName =username;
            if(username != null && password !=null){
                if(password.equals(paswd)){
                    Home h = new Home();
                    Login.getFrames()[1].dispose();
                    LoginBack.getFrames()[1].dispose();
                    
                    new Home().setVisible(true);
                    
                }else{
                    JOptionPane.showMessageDialog(null, "Username or PIN Invalid", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }else{
                JOptionPane.showMessageDialog(null, "Please Enter the credentials", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            DBCon.closeCon();
        }catch(SQLException e){
            e.printStackTrace();
        }   
    }
    public  ResultSet userCont(){
        
        DBSearch search = new DBSearch();
        search.userSearch();
        rs = search.users;
        return rs;
    }
}
