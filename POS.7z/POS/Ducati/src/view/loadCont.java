/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author Pasindu
 */
public class loadCont {
    public static void main(String[] args){
        Loading load =new Loading();
        load.setVisible(true);
        
        try{
            int i;
            for(i=0;i<=100;i++){
                Thread.sleep(50);
            Loading.loadB.setValue(i);
                if(i==100){
                    load.setVisible(false); 
                // new LoginBack().setVisible(true);
                 new Login().setVisible(true);
                }
            }
            
        }catch(Exception e){
        }
    }
}
