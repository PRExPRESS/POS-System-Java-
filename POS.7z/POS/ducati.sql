-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 01, 2021 at 10:03 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ducati`
--

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
CREATE TABLE IF NOT EXISTS `agent` (
  `agent_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  PRIMARY KEY (`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`agent_id`, `name`, `contact`, `email`, `address`) VALUES
('AG100', 'Pubudu Chinthaka', '+94754553466', 'pubuduchinthaka@gmail.com', 'Madawachchiya, Sri Lanka'),
('AG120', 'John Smith', '+1(201)8005234', 'johnmortors@gmail.com', 'Elkton, Maryland');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `ch_num` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `engine` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `year` date NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`ch_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ch_num`, `model`, `engine`, `price`, `year`, `status`) VALUES
('CH-200 100 020', 'Panigale', '1200CC L-Twin', 25000, '2020-09-01', 'Active'),
('CH-200 100 010', 'Panigale', '1200CC L-Twin', 25000, '2020-11-01', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `total` float NOT NULL,
  PRIMARY KEY (`sales_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `date`, `total`) VALUES
(9, '2021-05-01', 25000),
(10, '2021-05-01', 47000),
(11, '2021-05-01', 72000),
(12, '2021-05-01', 69000),
(13, '2021-05-01', 25000),
(14, '2021-05-01', 47000),
(15, '2021-05-01', 25000),
(16, '2021-05-01', 25000),
(17, '2021-05-01', 25000),
(18, '2021-05-01', 25000),
(19, '2021-05-01', 22000),
(20, '2021-05-01', 22000),
(21, '2021-05-01', 22000),
(22, '2021-05-01', 22000),
(23, '2021-05-01', 22000),
(24, '2021-05-01', 22000),
(25, '2021-05-01', 25000),
(26, '2021-05-01', 22000),
(27, '2021-05-02', 22000),
(28, '2021-05-02', 25000),
(29, '2021-05-02', 25000),
(30, '2021-05-02', 25000),
(31, '2021-05-02', 25000),
(32, '2021-05-02', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `sales_product`
--

DROP TABLE IF EXISTS `sales_product`;
CREATE TABLE IF NOT EXISTS `sales_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_id` int(11) NOT NULL,
  `agent_id` varchar(20) NOT NULL,
  `ch_num` varchar(20) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_product`
--

INSERT INTO `sales_product` (`id`, `sales_id`, `agent_id`, `ch_num`, `price`) VALUES
(9, 9, 'AG100', 'CH-200 100 010', 25000),
(10, 10, 'AG100', 'CH-200 100 010', 25000),
(11, 10, 'AG100', 'CH-100 100 010', 22000),
(12, 11, 'AG120', 'CH-200 100 010', 25000),
(13, 11, 'AG120', 'CH-100 100 010', 22000),
(14, 11, 'AG120', 'CH-200 100 020', 25000),
(15, 12, 'AG120', 'CH-200 100 010', 25000),
(16, 12, 'AG120', 'CH-100 100 010', 22000),
(17, 12, 'AG120', 'CH-100 100 010', 22000),
(18, 13, 'AG120', 'CH-200 100 010', 25000),
(19, 14, 'AG120', 'CH-200 100 010', 25000),
(20, 14, 'AG120', 'CH-100 100 010', 22000),
(21, 15, 'AG120', 'CH-200 100 010', 25000),
(22, 16, 'AG100', 'CH-200 100 010', 25000),
(23, 17, 'AG120', 'CH-200 100 010', 25000),
(24, 18, 'AG100', 'CH-200 100 010', 25000),
(25, 19, 'AG120', 'CH-100 100 010', 22000),
(26, 20, 'AG120', 'CH-100 100 010', 22000),
(27, 21, 'AG120', 'CH-100 100 010', 22000),
(28, 22, 'AG120', 'CH-100 100 010', 22000),
(29, 23, 'AG120', 'CH-100 100 010', 22000),
(30, 24, 'AG100', 'CH-100 100 010', 22000),
(31, 25, 'AG100', 'CH-200 100 010', 25000),
(32, 26, 'AG100', 'CH-100 100 010', 22000),
(33, 27, 'AG100', 'CH-100 100 010', 22000),
(34, 28, 'AG100', 'CH-200 100 010', 25000),
(35, 29, 'AG100', 'CH-200 100 020', 25000),
(36, 30, 'AG100', 'CH-200 100 020', 25000),
(37, 31, 'AG100', 'CH-200 100 010', 25000),
(38, 32, 'AG100', 'CH-200 100 010', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `emp_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pin` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(15) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`emp_id`, `name`, `username`, `pin`, `email`, `contact`) VALUES
('EMP2019175', 'Pasindu Rashmika', 'PasinduR', 1998, 'amp@gmail.com', '0715918586');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
